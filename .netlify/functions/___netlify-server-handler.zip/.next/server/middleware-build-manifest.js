globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/uLyU62RsfjLaW4k1Zd2DK/_buildManifest.js",
    "static/uLyU62RsfjLaW4k1Zd2DK/_ssgManifest.js",
    "static/uLyU62RsfjLaW4k1Zd2DK/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1inwntv0b4r-7.js",
    "static/chunks/2nbksftlhvbm-.js",
    "static/chunks/3d-102xox8shi.js",
    "static/chunks/34wvn5zw0a69w.js",
    "static/chunks/turbopack-2i5xcmkbpagtb.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
